package com.example.demo.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp6")
public class Employee {

	@Id
	@Column(name="empno") private int employeeNumber;
	
	@Column(name="ename") private String employeeName;
	@Column(name="job") private String employeeJob;
	@Column(name="mgr") private Integer managerCode;
	@Column(name="hiredate") private LocalDate hiredate;
	@Column(name="sal") private Float salary;
	@Column(name="comm") private Float commision;
	@Column(name="deptno") private Integer departmentNumber;
	
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeJob() {
		return employeeJob;
	}
	public void setEmployeeJob(String employeeJob) {
		this.employeeJob = employeeJob;
	}
	public Integer getManagerCode() {
		return managerCode;
	}
	public void setManagerCode(Integer managerCode) {
		this.managerCode = managerCode;
	}
	public LocalDate getHiredate() {
		return hiredate;
	}
	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}
	public Float getSalary() {
		return salary;
	}
	public void setSalary(Float salary) {
		this.salary = salary;
	}
	public Float getCommision() {
		return commision;
	}
	public void setCommision(Float commision) {
		this.commision = commision;
	}
	public Integer getDepartmentNumber() {
		return departmentNumber;
	}
	public void setDepartmentNumber(Integer departmentNumber) {
		this.departmentNumber = departmentNumber;
	}
	
	
}
