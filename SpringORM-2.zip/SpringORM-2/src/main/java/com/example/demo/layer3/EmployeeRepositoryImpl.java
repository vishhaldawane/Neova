package com.example.demo.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Department;
import com.example.demo.layer2.Employee;

@Repository
public class EmployeeRepositoryImpl extends BaseRepository implements EmployeeRepository {

	
	public EmployeeRepositoryImpl() {
			System.out.println("EmployeeRepositoryImpl ..");	
	}

	@Override
	public List<Employee> selectEmployees() {
		return super.findAll("Employee");
	}
	

}
