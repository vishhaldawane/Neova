package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.UserRepositoryImpl;
import com.example.pojo.User;


@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired UserRepositoryImpl userRepo;
	
	@GetMapping("/get/{eId}")  //localhost:8080/dept/get/1
	public User getUser(@PathVariable("uId") int x)
	{
		User user;
		user = userRepo.selectUser(x);
		return user;
	}
	
	@GetMapping("/getAll")  //localhost:8080/dept/get/1
	public List <User> getUsers()
	{
		List <User> userList;
		userList = userRepo.selectUsers();
		return userList;
	}
	
//	@PutMapping("/update")
//	public void updateUser(@RequestBody User eObj)
//	{
//		userRepo.updateUser(eObj);
//	}
	
	@PutMapping("/delete/{uId}")
	public void deleteUser(@PathVariable("uId") int x)
	{
		userRepo.deleteUser(x);
	}
}
