package com.example.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "retailer")
public class Retailer {

	@Id
	@GeneratedValue
	@Column(name = "retailerId")
	private int retailerId;
	
	@Column(name = "name")
	private String name;

	@Column(name = "mobileNumber")
	private long mobileNumber;

	@Column(name = "password")
	private String password;
	
	@ManyToOne
	@JoinColumn(name = "adminId_FK")
	private Admin admin;
	
	
	public int getRetailerId() {
		return retailerId;
	}

	public void setRetailerId(int retailerId) {
		this.retailerId = retailerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "Retailer [retailerId=" + retailerId + ", name=" + name + ", mobileNumber=" + mobileNumber
				+ ", password=" + password + ", admin=" + admin + "]";
	}

	
	
}
