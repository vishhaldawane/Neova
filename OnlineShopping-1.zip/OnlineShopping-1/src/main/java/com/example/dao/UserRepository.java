package com.example.dao;

import java.util.List;

import com.example.pojo.User;

public interface UserRepository {

	void insertUser(User eObj); //C

	User selectUser(int eId); //R
	List<User> selectUsers(); //RA

	void updateUsert(User eObj); //U
	void deleteUser(int eId); //D

}
