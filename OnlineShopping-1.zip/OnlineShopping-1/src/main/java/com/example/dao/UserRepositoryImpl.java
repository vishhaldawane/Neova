package com.example.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.pojo.User;

@Repository
public class UserRepositoryImpl extends BaseRepository implements UserRepository {

	@Transactional
	public void insertUser(User eObj) {
		// TODO Auto-generated method stub

	}

	@Override
	public User selectUser(int eId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> selectUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Transactional
	public void updateUsert(User eObj) {
		// TODO Auto-generated method stub

	}

	@Transactional
	public void deleteUser(int eId) {
		// TODO Auto-generated method stub

	}

}
