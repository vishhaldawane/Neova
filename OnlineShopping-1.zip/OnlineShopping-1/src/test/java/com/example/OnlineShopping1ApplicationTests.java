package com.example;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.pojo.Address;
import com.example.pojo.Admin;
import com.example.pojo.Retailer;
import com.example.pojo.User;
import com.example.pojo.Wishlist;

@SpringBootTest
class OnlineShopping1ApplicationTests {
	
	@Test
	public void insertUser() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 

		System.out.println("Entity Manager Factory : "+entityManagerFactory);

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		System.out.println("Entity Manager : "+entityManager);

		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();

			User user = new User();
			user.setName("Shubham");
			user.setEmail("Shubham@gmail.com");
			user.setPassword("Shubham123");
			user.setMobileNumber(9405405443l);

			entityManager.persist(user);
		
			transaction.commit();
	}
	
	@Test
	public void insertAddress() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 

		System.out.println("Entity Manager Factory : "+entityManagerFactory);

		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		System.out.println("Entity Manager : "+entityManager);

		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();

			Address address = new Address();
			address.setAddressLine("Magarpatta");
			address.setState("Mahjarashtra");
			address.setCity("Pune");
			address.setPostalCode(411028);

			entityManager.persist(address);
		
			transaction.commit();
	}
	
	//----------------------------------------------------//
	
	@Test
	public void insertAdmin() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
			Admin admin = new Admin(); //new/blank entity object 
			admin.setName("Ritika");
			admin.setPassword("ritika123");
			
			entityManager.persist(admin); //generate the insert query for us 
		transaction.commit();
	
	}

	@Test
	public void insertUserWithWishList() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
			User ruser = new User(); //new/blank entity object 
			ruser.setName("Lakhan");
			ruser.setEmail("lakhan@gmail.com");
			ruser.setPassword("lakhan123");
			
			Wishlist wishList = new Wishlist();
//			wishList.setProdId(0);
			
			ruser.setWishList(wishList); //set the FK
			wishList.setUserIdFK(ruser);//set the FK
			
			entityManager.persist(ruser);
			entityManager.persist(wishList); //generate the insert query for us 

			
			
		transaction.commit();
	
	}

	//-----------------------------//
	
	
	@Test
	public void insertRetailer() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
			Retailer retailer = new Retailer(); //new/blank entity object 
			
			retailer.setName("Rishi");
			retailer.setMobileNumber(940540543);
			retailer.setPassword("rishi123");
			
			
			entityManager.persist(retailer); //generate the insert query for us 
		transaction.commit();
	                   
	}
	
	@Test
	public void insertRetailerWithAdmin() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA"); //persistence.xml is read here 
		
		System.out.println("Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		//ctrl+shift+M
		
		System.out.println("Entity Manager : "+entityManager);
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		
		Admin admin = new Admin(); //new/blank entity object 
				
			Retailer retailer = new Retailer();
			
			retailer.setName("Rishii");
			retailer.setMobileNumber(9405405443l);
			retailer.setPassword("rishi123");
			
			
//			admin.setWishList(wishList); //set the FK
			retailer.setAdmin(admin);//set the FK
			
			entityManager.persist(admin);
			entityManager.persist(retailer); //generate the insert query for us 

			
			
		transaction.commit();
	
	}

}
