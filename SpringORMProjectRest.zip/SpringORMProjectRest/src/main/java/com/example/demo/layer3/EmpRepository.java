package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Department;
import com.example.demo.layer2.EmpLoyeePojo;

@Repository
public interface EmpRepository {

	void insertEmployee(EmpLoyeePojo empPojo);
	
	EmpLoyeePojo selectEmployee(int empNo);
	
	List<EmpLoyeePojo> selectEmployees();
	
	void updateEmployee(EmpLoyeePojo empPojo);
	
	void deleteEmployee(int empNo);
	
}
