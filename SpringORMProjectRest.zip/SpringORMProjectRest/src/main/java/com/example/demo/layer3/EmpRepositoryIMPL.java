package com.example.demo.layer3;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Department;
import com.example.demo.layer2.EmpLoyeePojo;

@Repository
public class EmpRepositoryIMPL extends BaseRepository implements EmpRepository {

	public EmpRepositoryIMPL() {
		System.out.println("EmpRepositoryIMPL() ..");

	}

	@Transactional
	public void insertEmployee(EmpLoyeePojo empPojo) {
		super.persist(empPojo); // invoking the dummy persist of the super class
		System.out.println("department inserted...");

	}

	@Override
	public EmpLoyeePojo selectEmployee(int empNo) {
		System.out.println("EmpRepositoryIMPL : selecting department by deptno");
		EmpLoyeePojo emp4 = super.find(EmpLoyeePojo.class, empNo);

		return emp4;
	}

	@Override
	public List<EmpLoyeePojo> selectEmployees() {
		List<EmpLoyeePojo> deptList = new ArrayList<EmpLoyeePojo>();

		System.out.println("EmpRepositoryIMPL : Selecting all departments...");
		return super.findAll("EmpLoyeePojo");
	}

	@Transactional
	public void updateEmployee(EmpLoyeePojo empPojo) {
		System.out.println("EmpRepositoryIMPL : Updating Employee...");
		super.merge(empPojo);

	}

	@Transactional
	public void deleteEmployee(int empNo) {
		System.out.println("EmpRepositoryIMPL : Deleting Employee");
		super.remove(EmpLoyeePojo.class, empNo);
	}

}
