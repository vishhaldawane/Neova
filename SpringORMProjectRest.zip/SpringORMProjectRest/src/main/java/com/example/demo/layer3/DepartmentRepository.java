package com.example.demo.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Department;

@Repository
public interface DepartmentRepository {
	void insertDepartment(Department dobj);

	Department selectDepartment(int dno);

	List<Department> selectDepartments();

	void updateDepartment(Department dobj);

	void deleteDepartment(int dno);

}