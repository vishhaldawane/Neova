package com.example.demo.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EMP6")
public class EmpLoyeePojo {
	
	@Id
	@Column(name="EMPNO")
	private int empNo;
	
	@Column(name="ENAME")
	private String empName;
	
	@Column(name="JOB")
	private String job;
	
	@Column(name="MGR")
	private int mgr;
	
	@Column(name="HIREDATE")
	private LocalDate hireDate; 
	
	@Column(name="SAL")
	private double sal;
	
	@Column(name="COMM")
	private Integer comm;
	
	@Column(name="DEPTNO")
	private int deptno;

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public int getMgr() {
		return mgr;
	}

	public void setMgr(int mgr) {
		this.mgr = mgr;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}

	public Integer getComm() {
		return comm;
	}

	public void setComm(Integer comm) {
		this.comm = comm;
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	
	
	
	
	
}
