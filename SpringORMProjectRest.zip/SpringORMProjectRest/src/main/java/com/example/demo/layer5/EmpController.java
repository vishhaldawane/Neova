package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Department;
import com.example.demo.layer2.EmpLoyeePojo;
import com.example.demo.layer3.EmpRepositoryIMPL;

@RestController
@RequestMapping("/emp")
public class EmpController {

	@Autowired
	EmpRepositoryIMPL empRepo;

	@GetMapping("/get/{eno}")
	public EmpLoyeePojo getEmp(@PathVariable("eno") int x) {
		EmpLoyeePojo emp;
		emp = empRepo.selectEmployee(x);
		return emp;

	}

	@GetMapping("/getAll")
	public List<EmpLoyeePojo> getEmps() {
		List<EmpLoyeePojo> empList;
		empList = empRepo.selectEmployees();
		return empList;
	}

	@PostMapping("/add")
	public void addEmp(@RequestBody EmpLoyeePojo empObj) {
		empRepo.insertEmployee(empObj);

	}

	@PutMapping("/update")
	public void updateEmp(@RequestBody EmpLoyeePojo EmpObj) {
		empRepo.updateEmployee(EmpObj);

	}

	@PutMapping("/delete/{eno}")
	public void deleteEmp(@PathVariable("eno") int x) {
		empRepo.deleteEmployee(x);

	}

}
