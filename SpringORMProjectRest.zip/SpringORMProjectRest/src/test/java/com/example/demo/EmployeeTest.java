package com.example.demo;

import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Department;
import com.example.demo.layer2.EmpLoyeePojo;

import com.example.demo.layer3.EmpRepositoryIMPL;

@SpringBootTest
public class EmployeeTest {

	@Autowired
	EmpRepositoryIMPL empRepo;

	@Test
	void insertEmpTest() {
		LocalDate ld = LocalDate.of(1998, 9, 8);
		EmpLoyeePojo emp1 = new EmpLoyeePojo();

		emp1.setEmpNo(8044);
		emp1.setEmpName("Lakhan");
		emp1.setJob("Developer");
		emp1.setHireDate(ld);
		// emp1.setHireDate(ld);
		emp1.setMgr(7934);
		emp1.setSal(55000.5);
		emp1.setComm(5000);
		emp1.setDeptno(30);
		empRepo.insertEmployee(emp1);
		// stuRepo.insertDepartment(dept);

	}

	@Test
	void selectEmpTest() {
		EmpLoyeePojo emp3;
		emp3 = empRepo.selectEmployee(8034);
		System.out.println("Emp No  :" + emp3.getEmpNo());
		System.out.println("Emp Name  :" + emp3.getEmpName());
		System.out.println("Emp Mgr  :" + emp3.getMgr());
		System.out.println("Emp Job  :" + emp3.getJob());

		System.out.println("Emp HireDate  :" + emp3.getHireDate());
		System.out.println("Emp Sal  :" + emp3.getSal());

		System.out.println("Emp COMM  :" + emp3.getComm());

		System.out.println("Emp DeptNo  :" + emp3.getDeptno());

	}

	@Test
	void updateEmp() {
		LocalDate ld = LocalDate.now();
		EmpLoyeePojo emp2 = new EmpLoyeePojo();
		emp2.setEmpNo(8034);
		emp2.setEmpName("lucky");
		emp2.setJob("DEVOPS");
		emp2.setMgr(7934);
		emp2.setHireDate(ld);
		emp2.setSal(40000.2);
		emp2.setComm(555);
		emp2.setDeptno(20);

		empRepo.updateEmployee(emp2);

	}

	@Test
	void deleteEmp() {
		EmpLoyeePojo emp = new EmpLoyeePojo();
		// dept.setDepartmentNumber(65);

		empRepo.deleteEmployee(8044);
	}

	@Test
	void selectAllEmpTest() {
		List<EmpLoyeePojo> empList;
		empList = empRepo.selectEmployees();
		for (EmpLoyeePojo emp1 : empList) {
			System.out.println("Emp No. :" + emp1.getDeptno());
			System.out.println("Emp Name. :" + emp1.getEmpName());
			System.out.println("EMp Job. :" + emp1.getJob());
			System.out.println("EMp MGR. :" + emp1.getMgr());
			System.out.println("EMp HIREDATE. :" + emp1.getHireDate());
			System.out.println("EMp SALARY. :" + emp1.getSal());
			System.out.println("EMp COMMISSION. :" + emp1.getComm());
			System.out.println("EMp DEPT.NO.    :" + emp1.getDeptno());

		}
	}

}
