package com.example.demo;

import java.time.LocalDate;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Department;

import com.example.demo.layer3.DepartmentRepositoryImpl;

@SpringBootTest
class SpringOrmProjectRestApplicationTests {

	@Autowired
	DepartmentRepositoryImpl deptRepo;

	@Test
	void insertDeptTest() {
		Department dept = new Department();
		dept.setDepartmentNumber(555);
		;
		dept.setDepartmentName("Operation");
		dept.setDepartmentLocation("Solapur");

		deptRepo.insertDepartment(dept);

	}

	@Test
	void selectDeptTest() {
		Department dept;
		dept = deptRepo.selectDepartment(55);
		System.out.println("Dept No:" + dept.getDepartmentNumber());
		System.out.println("Dept Name:" + dept.getDepartmentName());
		System.out.println("Dept Location:" + dept.getDepartmentLocation());

	}

	@Test
	void selectAllDEptTest() {
		List<Department> deptList;
		deptList = deptRepo.selectDepartments();
		for (Department dept : deptList) {
			System.out.println("Dept No. :" + dept.getDepartmentNumber());
			System.out.println("Dept Name. :" + dept.getDepartmentName());
			System.out.println("Dept Location. :" + dept.getDepartmentLocation());

		}
	}

	@Test
	void updateDept() {
		Department dept = new Department();
		dept.setDepartmentNumber(55);
		;
		dept.setDepartmentName("research");
		dept.setDepartmentLocation("mumbai");

		deptRepo.updateDepartment(dept);

	}

	@Test
	void deleteDepartment() {
		Department dept = new Department();
		// dept.setDepartmentNumber(65);

		deptRepo.deleteDepartment(55);
	}

}
