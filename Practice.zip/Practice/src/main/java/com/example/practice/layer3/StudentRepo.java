package com.example.practice.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.practice.layer2.Student;

@Repository
public interface StudentRepo {
	
	
	
	void insertStudent ( Student studObj);
	
	void updateStudent (int roll);
	

}
