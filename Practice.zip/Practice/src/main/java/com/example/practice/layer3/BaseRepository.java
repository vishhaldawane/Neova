package com.example.practice.layer3;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

@Repository
public class BaseRepository {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	
	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}



	@Transactional
	public void persist(Object obj) { // persist is a dummy/userdefined name

		try {
				entityManager.persist(obj);			
		} finally { entityManager.close(); }

	}
	
	
	public void merg(int obj) {
		entityManager.merge(obj);
		
		entityManager.close();
		
		
	}






}
