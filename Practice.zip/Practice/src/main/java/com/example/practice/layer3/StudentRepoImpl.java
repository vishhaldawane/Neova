package com.example.practice.layer3;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.practice.layer2.Student;
@Repository
public class StudentRepoImpl extends BaseRepository implements StudentRepo {

@Transactional
	public void insertStudent(Student studObj) {
	
		super.persist(studObj);
	}

@Override
public void updateStudent(int roll) {
	super.merg(roll);
	
}

	
}
