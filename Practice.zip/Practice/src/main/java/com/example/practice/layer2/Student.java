package com.example.practice.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studentinfo")
public class Student {

	@Id
	@GeneratedValue
	private int rollNo;
	
	@Column(name = "Name")
	private String name;
	
	
	
	@Column(name="Div"  )
	private String div;



	public int getRollNo() {
		return rollNo;
	}



	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getDiv() {
		return div;
	}



	public void setDiv(String div) {
		this.div = div;
	}
	

	

}
