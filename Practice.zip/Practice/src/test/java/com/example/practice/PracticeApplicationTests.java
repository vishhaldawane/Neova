package com.example.practice;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.practice.layer2.Student;
import com.example.practice.layer3.StudentRepoImpl;

@SpringBootTest
class PracticeApplicationTests {

	@Autowired
	StudentRepoImpl studRepoImpl;
	@Test
	void insertStudentTest() {
		Student studObj=new Student();
		
//		studObj.setRollNo(101);

		studObj.setName("Shubham");
		
		studObj.setDiv("A");
		studRepoImpl.insertStudent(studObj);
	}
	
	
	
	void updateStudentTest() {
		Student studObj=new Student();
		studObj.setDiv("B");
		
		studObj.setName("Lakhan");
		
		studRepoImpl.updateStudent(1);
	}

}
