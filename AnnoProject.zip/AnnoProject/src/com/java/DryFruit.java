package com.java;



@Gift(from="Disha",to="Roshni")
public class DryFruit {

}
