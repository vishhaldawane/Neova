package com.java;

import java.lang.annotation.Annotation;
import java.util.Iterator;

public class TestAnno {
	public static void main(String[] args) {
		
		
		Sweet sw = new Sweet();
		
		Class classInfo = sw.getClass();
		
		Annotation annos[]= classInfo.getAnnotations();
		
		for(Annotation theAnno : annos) {
			Gift g = (Gift) theAnno;
			
			if(g.from().equals("Kalpesh")) {
				System.out.println("Wow its from the Founder member....");
			}
			else {
				System.out.println("Its not from the Founder...its from my native friend ...");
			}
			
			if(g.to().equals("Sanket")) {
				System.out.println("Its for me...");
			}
			else {
				System.out.println("Its not for sanket ..its for someone else in the home...");
			}
			
		//	System.out.println("From "+g.from());
		//	System.out.println("To   "+g.to());
		}
	}
}
