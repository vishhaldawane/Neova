package com.java;


@Gift(from="Vishal",to="Ajinkya")
public class Sweet {

}
