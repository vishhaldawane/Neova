package com.java.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.layer2.Flight;
import com.java.layer3.FlightRepository;

@Service("flightService")
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository flightRepo;
	
	public FlightServiceImpl() {
		System.out.println("FlightServiceImpl()");
	}
	public List<Flight> getAllFlightsService() {
		
		return flightRepo.getAllFlights();
	}

	public List<Flight> getAvailableFlightsService(String source, String dest) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Flight> getAvailableFlightsService(String city) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
