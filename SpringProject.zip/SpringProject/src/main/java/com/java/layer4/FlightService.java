package com.java.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.java.layer2.Flight;

@Service
public interface FlightService {
	List<Flight> getAllFlightsService();
	List<Flight> getAvailableFlightsService(String source, String dest);
	List<Flight> getAvailableFlightsService(String city);	
}
