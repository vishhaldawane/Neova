package com.java.anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("engine")
@Scope("prototype")
public class SedanEngine {
	
	public SedanEngine() {
		System.out.println("SedanEngine().....");
	
	}
	public void startSedanEngine() {
		System.out.println("Starting the sedan engine...");
	}
	
}
