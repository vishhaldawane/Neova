package com.java.anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("petrol")
@Scope("prototype")
public class PetrolEngine extends SedanEngine {
	public PetrolEngine() {
		//super();
		System.out.println("PetrolEngine() ....");
		System.out.println("-------");
	}
	
	public void startSedanEngine() {
		System.out.println("Starting the petrol sedan engine...");
	}
	
}
