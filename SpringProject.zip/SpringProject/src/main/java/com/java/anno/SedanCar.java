package com.java.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("mySedanCar")
@Scope("prototype")
public class SedanCar {
	/*@Autowired	SedanEngine se; 	@Autowired PetrolEngine pe; @Autowired	DieselEngine de;*/
	@Autowired 	@Qualifier("engine")
	SedanEngine sedanEngine1; //just a reference - hasA

	@Autowired 	@Qualifier("petrol")
	SedanEngine sedanEngine2;
	
	@Autowired 	@Qualifier("diesel")
	SedanEngine sedanEngine3;
	
	
	public SedanCar() {
		super();
		System.out.println("SedanCar() engine...");
		System.out.println("-------");
	}
	public void startSedanCar() {
		System.out.println("Starting the sedan car ......");
		sedanEngine1.startSedanEngine();
		sedanEngine2.startSedanEngine();
		sedanEngine3.startSedanEngine();
		
	}
	
}

/*



Marks a constructor, field, setter method, or config method as
 to be autowired by Spring's dependency injection facilities. 
 This is an alternative to the JSR-330 javax.inject.Inject 
 annotation, adding required-vs-optional semantics.

Only one constructor of any given bean class may 
declare this annotation with the 'required' 
attribute set to true, 
indicating the constructor to autowire when used as a
 Spring bean. 
 Furthermore, if the 'required' 
 attribute is set to true, only a single 
 constructor may be annotated with @Autowired. 
 If multiple non-required constructors declare the annotation,
  they will be considered as candidates for autowiring.
The constructor with the greatest number of dependencies 
that can be satisfied by 
matching beans in the Spring container will be chosen. 
If none of the candidates can be satisfied, then a primary/default constructor (if present) will be used. If a class only declares a single constructor to begin with, it will always be used, even if not annotated. An annotated constructor does not have to be public.

*/










