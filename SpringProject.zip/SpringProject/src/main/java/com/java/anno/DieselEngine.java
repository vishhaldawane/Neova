package com.java.anno;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("diesel")
@Scope("prototype")
public class DieselEngine extends SedanEngine {
	public DieselEngine() {
		System.out.println("DieselEngine().....");
		System.out.println("-------");
	}
	public void startSedanEngine() {
		System.out.println("Starting the diesel sedan engine...");
	}
}
