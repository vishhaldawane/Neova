/*package com.java.anno;

import org.springframework.stereotype.Component;

@Component
class GrandFather {
	GrandFather() {
		System.out.println("GrandFather()....");
	}
}

@Component
class Father extends GrandFather
{
	Father() {
		//super();
		System.out.println("Father()....");
	}
}

@Component
class Child extends Father
{
	Child() {
		//super();
		System.out.println("Child() ctor...");
		
	}
}
*/