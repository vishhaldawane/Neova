/*package com.java.anno;

class Animal { }

class Mammal extends Animal { 
	int age;
	char gender;
}

class Human extends Mammal { 
	boolean canThink;
}
class Person extends Human { 
	PanCard p = new PanCard();
}
class Student extends Person { }

class Employee extends Student {
	SalarySlip sal = new ....
}
class Teacher extends Employee { }
class Principal extends Teacher { }

class Student extends HeadMaster 
{
	
}

public class Test3 {
	
}
*/