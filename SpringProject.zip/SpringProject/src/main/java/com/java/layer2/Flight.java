package com.java.layer2;

public class Flight {
	 private int flightNumber;
	 private String flightName;
	 private String source ;
	 private String destination;

	 
	 public Flight() {
		 System.out.println("Flight()....");
	 }


	public int getFlightNumber() {
		return flightNumber;
	}


	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}


	public String getFlightName() {
		return flightName;
	}


	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}
	 
	 
}


