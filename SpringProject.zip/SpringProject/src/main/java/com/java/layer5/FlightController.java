package com.java.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.layer2.Flight;
import com.java.layer4.FlightService;



// http://localhost:8080/flight/getAll

@RestController
@RequestMapping("/flight")
public class FlightController {
	
	//@Autowired
	//static FlightService flightService;
	
	//public static void main(String[] args) {
	
	@RequestMapping("/getAll")
	public List<Flight> getAllFlights() {
		
		ApplicationContext container = new ClassPathXmlApplicationContext("SpringAnnoConfig.xml");
		FlightService flightService = container.getBean(FlightService.class);
			
		List<Flight> flightList = flightService.getAllFlightsService();
		
	/*	for(Flight theFlight : flightList) {
			System.out.println("Flight Number      : "+theFlight.getFlightNumber());
			System.out.println("Flight Name        : "+theFlight.getFlightName());
			System.out.println("Flight Source      : "+theFlight.getSource());
			System.out.println("Flight Destination : "+theFlight.getDestination());
			System.out.println("-------------");
		}*/
		return flightList;
	}
}
