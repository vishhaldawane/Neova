package com.java.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.java.layer2.Flight;

@Repository
public interface FlightRepository {
	List<Flight> getAllFlights();
	List<Flight> getAvailableFlights(String source, String dest);
	List<Flight> getAvailableFlights(String city);	
}

		
