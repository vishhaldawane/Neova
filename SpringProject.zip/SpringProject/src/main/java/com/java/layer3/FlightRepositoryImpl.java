package com.java.layer3;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ImportResource;
import org.springframework.stereotype.Repository;

import com.java.layer2.Flight;
//spring JDBC

@Repository("flightRepo")
public class FlightRepositoryImpl implements FlightRepository {


	@Autowired
	DataSource dataSource; // spring will inject the instance of DriverManagerDataSource
	
	/*public void setDataSource(DataSource source) {
		System.out.println("setDataSource() invoked...");
		this.dataSource = source;
	}*/
	
	
	
	//@Autowired
	//Instrument instr;
	
	FlightRepositoryImpl() {
		//load the driver
		//get the connection
		
		
		
	}
	
	public List<Flight> getAllFlights() {
				
		
		List<Flight> flightList = new ArrayList<Flight>();
		
				try {
					Connection conn = dataSource.getConnection();
					System.out.println("getAllFlights()....."+conn);
					
					Statement st = conn.createStatement();
					ResultSet rs = st.executeQuery("select * from flight");
					
					while(rs.next()) {
						Flight theFlight = new Flight();
						theFlight.setFlightNumber(rs.getInt(1));
						theFlight.setFlightName(rs.getString(2));
						theFlight.setSource(rs.getString(3));
						theFlight.setDestination(rs.getString(4));
						
						flightList.add(theFlight) ;// fillup the arraylist
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
				return flightList;
	}

	public List<Flight> getAvailableFlights(String source, String dest) {
		
		return null;
	}

	public List<Flight> getAvailableFlights(String city) {
		
		return null;
	}

}
