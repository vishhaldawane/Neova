create table flight
(
      flightNumber int,
      flightName varchar(20),
      source varchar(20),
      destination varchar(20)
);
insert into flight values (10,'Lufthansa','Munbai','Germany');
insert into flight values (20,'Air India','Munbai','Washington');
insert into flight values (30,'American Airlines','Munbai','New York');
insert into flight values (40,'British Airways','Munbai','London');
insert into flight values (50,'Air France','Munbai','Paris');

insert into flight values (40,'British Airways','London','Mumbai');
insert into flight values (50,'Air France','Paris','Mumbai');

