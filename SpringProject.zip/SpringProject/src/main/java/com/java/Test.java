package com.java;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

abstract class Mammal { }
abstract class Human extends Mammal { }
class Person extends Human { }

public class Test {
	public static void main(String[] args) {
		Human m = new Person();
		
		//ClarifiedButter    ghee      = new Butter().boil();
		
		System.out.println("Loading the container,.");
		ApplicationContext container = new ClassPathXmlApplicationContext("SpringConfig.xml");
		System.out.println("--------------");
		System.out.println("Container is loaded...");
		
			Car theCar1 = (Car) container.getBean("mycar");
		System.out.println("got the car "+theCar1);
		
		Car theCar2 = (Car) container.getBean("mycar");
		System.out.println("got the car "+theCar2);
		
		Car theCar3 = (Car) container.getBean("mycar");
		System.out.println("got the car "+theCar3);
		
		Department dept = container.getBean("mydept",Department.class); //.class is not the extension , it is one of the static member of the class
		//dept.setDepartmentNumber(10);
	//	dept.setDepartmentName("Learning");
	//	dept.setDepartmentLocation("Pune");

		System.out.println("dept no   : "+dept.getDepartmentNumber());
		System.out.println("dept name : "+dept.getDepartmentName());
		System.out.println("dept loc  : "+dept.getDepartmentLocation());
		
		
//		String pistonType = "TwinSpark";
//		Piston pist = new Piston(pistonType);
//		Engine theEngine = new Engine(pist);
//		Car theCar2 = new Car(theEngine);
//		
		
		//theCar.startCar();
	}
}

/*
The scope of this bean: typically "singleton" (one shared instance, which will be returned by all calls to getBean with the 
		 given id), 
		 
		 or "prototype" (independent instance resulting from each call to getBean). 
		 
		 By default, a bean will be a 
		 singleton, 
		 
		 unless the bean has a parent bean definition in which case it will inherit the parent's scope. 
		 
		 Singletons are 
		 most commonly used, and are ideal for multi-threaded service objects.
		 
		  Further scopes, such as "request" or "session", 
		 might be supported by extended bean factories (e.g. in a web environment). Inner bean definitions inherit the scope of 
		 their containing bean definition, unless explicitly specified: The inner bean will be a singleton if the containing bean is a 
		 singleton, and a prototype if the containing bean is a prototype, etc.
*/