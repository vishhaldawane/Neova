package com.java;


import org.springframework.context.ApplicationContext;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.java.anno.SedanCar;
import com.java.anno.SedanEngine;



public class TestAnno {
	public static void main(String[] args) {
		
		System.out.println("Loading the container,.");
		ApplicationContext 
		container = new 
		ClassPathXmlApplicationContext(
				"SpringAnnoConfig.xml");
		System.out.println("--------------");
		System.out.println("Container is loaded...");
		
		SedanCar car = container.getBean("mySedanCar",SedanCar.class);
		car.startSedanCar();
		
		System.out.println("------");
		
		
	}
}

/*
The scope of this bean: typically "singleton" (one shared instance, which will be returned by all calls to getBean with the 
		 given id), 
		 
		 or "prototype" (independent instance resulting from each call to getBean). 
		 
		 By default, a bean will be a 
		 singleton, 
		 
		 unless the bean has a parent bean definition in which case it will inherit the parent's scope. 
		 
		 Singletons are 
		 most commonly used, and are ideal for multi-threaded service objects.
		 
		  Further scopes, such as "request" or "session", 
		 might be supported by extended bean factories (e.g. in a web environment). Inner bean definitions inherit the scope of 
		 their containing bean definition, unless explicitly specified: The inner bean will be a singleton if the containing bean is a 
		 singleton, and a prototype if the containing bean is a prototype, etc.
*/