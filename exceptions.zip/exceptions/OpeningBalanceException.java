package com.java.exceptions;

public class OpeningBalanceException extends Exception {

	public OpeningBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
