package com.java.exceptions;

public class AccountNumberException extends Exception {
	
	//no data
	
	AccountNumberException(String msg) {
		super(msg);
	}
	
	
	//no function
}
