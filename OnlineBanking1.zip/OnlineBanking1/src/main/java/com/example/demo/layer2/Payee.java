package com.example.demo.layer2;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="payee")
public class Payee {
	@Id
	private int beneficiaryAccNo;  //pk
	            //private int accountNumber; // fk
	private String beneficiaryName;
	private String nickname;
	
	/**************mapping**************************/
	
	@OneToOne 
	private TransactionTable transactionTable;
	
	
	
	
	/************setter getter***************/
	
	public TransactionTable getTransactionTable() {
		return transactionTable;
	}
	public void setTransactionTable(TransactionTable transactionTable) {
		this.transactionTable = transactionTable;
	}
	
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	
	public int getBeneficiaryAccNo() {
		return beneficiaryAccNo;
	}
	
	
	public void setBeneficiaryAccNo(int beneficiaryAccNo) {
		this.beneficiaryAccNo = beneficiaryAccNo;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	
	
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	
	
	
	
	
	

}
