package com.example.demo.layer2;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="accountDetails")
public class AccountDetails {
	@Id
	private int accuntNumber;  //pk
	private String userID;
	private LocalDate createdOn;
	private String accountStatus;
	private String AccountLock;
	private String loginPaassword;
	private String TransactionPassword;
	private String accountType;
	private double accountBalance;
	      //private int custId;  //FK
	
	/**************mapping**************************/
	
	@OneToOne 
	private CustomerDetails customerDetails;
	
	
	
	
	/************setter getter***************/

    
	public CustomerDetails getCustomerDetails() {
		return customerDetails;
	}
	
	public void setCustomerDetails(CustomerDetails customerDetails) {
		this.customerDetails = customerDetails;
	}
	
	
	public int getAccuntNumber() {
		return accuntNumber;
	}
	public void setAccuntNumber(int accuntNumber) {
		this.accuntNumber = accuntNumber;
	}
	
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	
	
	public LocalDate getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}
	
	
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	
	
	public String getAccountLock() {
		return AccountLock;
	}
	public void setAccountLock(String accountLock) {
		AccountLock = accountLock;
	}
	
	
	public String getLoginPaassword() {
		return loginPaassword;
	}
	public void setLoginPaassword(String loginPaassword) {
		this.loginPaassword = loginPaassword;
	}
	
	
	public String getTransactionPassword() {
		return TransactionPassword;
	}
	public void setTransactionPassword(String transactionPassword) {
		TransactionPassword = transactionPassword;
	}
	
	
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	

}
