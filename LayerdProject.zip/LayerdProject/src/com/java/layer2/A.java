package com.java.layer2;

public class A {
	public  void foo() {
		System.out.println("A : Doing some pre...");
		System.out.println("A : foo() ");
		System.out.println("A : Doing some post...");
	}
}
