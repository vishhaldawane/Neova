package com.java.layer2;

//O<->R<->M

//Mapping this class with the Dept table


			//for dept table
public class Department {
	 
	 private  int departmentNumber ; // for deptno 
	 
	 private  String departmentName; // for dname
	 private  String departmentLocation; // for dloc
	
	 public Department() {
		 System.out.println("Department :  Department() contructor invoked.....");
	 }
	 
	 public int getDepartmentNumber() {
		return departmentNumber;
	}
	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getDepartmentLocation() {
		return departmentLocation;
	}
	public void setDepartmentLocation(String departmentLocation) {
		this.departmentLocation = departmentLocation;
	}

	 
	 
}
