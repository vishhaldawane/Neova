package com.java.layer4.exceptions;

public class DepartmentExistsException extends Exception {
	public DepartmentExistsException(String str) {
		super(str);
	}

}
