package com.java.layer4.exceptions;

public class DepartmentNotFoundException extends Exception {
	public DepartmentNotFoundException(String str) {
		super(str);
	}
}
