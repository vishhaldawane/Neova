package com.java.layer4;

import com.java.layer3.B;

public class C {
	B b = new B();
	public void fee() {
		System.out.println("\t\tC : Doing some pre...");

		b.far();
		System.out.println("\t\tC : fee() ");
		System.out.println("\t\tC : Doing some post...");

	}
}
