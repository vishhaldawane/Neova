package com.java.layer4;
import java.util.List;

import com.java.layer2.Department;
import com.java.layer4.exceptions.DepartmentExistsException;
import com.java.layer4.exceptions.DepartmentNotFoundException;
public interface DepartmentService {
	
	void createDepartmentService(Department dobj) throws DepartmentExistsException; //C
	List<Department> findAllDeptsService(); //RA
	
	Department findDeptService(int dno) throws DepartmentNotFoundException;
	
	
}
