package com.java.layer3;

import com.java.layer2.A;

public class B {
	A a = new A();
	public void far() {
		System.out.println("\tB : Doing some pre...");
		a.foo();
		System.out.println("\tB : far() ");
		System.out.println("\tB : Doing some post...");
	}
}
