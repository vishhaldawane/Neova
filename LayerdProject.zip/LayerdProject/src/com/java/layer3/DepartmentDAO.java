package com.java.layer3;

import java.util.List;

import com.java.layer2.Department;

public interface DepartmentDAO {
	void insertDepartment(Department dobj); //C
	
	Department selectDepartment(int dno); //R
	List<Department> selectDepartments(); //RA
	
	void updateDepartment(Department dobj); //U
	void deleteDepartment(int dno); //D
	
}
