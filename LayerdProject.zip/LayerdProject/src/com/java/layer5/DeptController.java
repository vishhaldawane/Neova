package com.java.layer5;

import java.util.List;

import com.java.layer2.Department;
import com.java.layer4.DepartmentServiceImpl;
import com.java.layer4.exceptions.DepartmentExistsException;
import com.java.layer4.exceptions.DepartmentNotFoundException;

public class DeptController {

	public static void main(String[] args) {

		DepartmentServiceImpl deptService = new DepartmentServiceImpl();
		
		  Department deptObj = new Department(); 
		  deptObj.setDepartmentNumber(66);
		  deptObj.setDepartmentName("Snack"); 
		  deptObj.setDepartmentLocation("DC"); 
		  try {
			deptService.createDepartmentService(deptObj);
		} catch (DepartmentExistsException e) {
			
			System.out.println("Problem : "+e.getMessage());
		}
		 

		/*List<Department> deptList = deptService.findAllDeptsService();
		for (Department theDept : deptList) {
			System.out.println("Dept NO   : " + theDept.getDepartmentNumber());
			System.out.println("Dept NAME : " + theDept.getDepartmentName());
			System.out.println("Dept LOC  : " + theDept.getDepartmentLocation());
			System.out.println("---------");
		}*/
		
		/*Department theDept;
		try {
			theDept = deptService.findDeptService(137);
			System.out.println("Dept NO   : " + theDept.getDepartmentNumber());
			System.out.println("Dept NAME : " + theDept.getDepartmentName());
			System.out.println("Dept LOC  : " + theDept.getDepartmentLocation());
			System.out.println("---------");
		} catch (DepartmentNotFoundException e) {
			System.out.println("Problem : "+e.getMessage());
		}*/
		
	}
}
