package com.java.layer5;

import com.java.layer4.C;

public class D {
	C c = new C();
	public void fun() {
		System.out.println("\t\t\tD : Doing some pre...");

		c.fee();
		System.out.println("\t\t\tD : fun() ");
		System.out.println("\t\t\tD : Doing some post...");

	}
}
