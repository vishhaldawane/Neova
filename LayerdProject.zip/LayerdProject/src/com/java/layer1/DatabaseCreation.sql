create table dept5
(
   deptno int,
   dname varchar(20),
   dloc varchar(20)
);

insert into dept5 values (10,'IT','NY');
insert into dept5 values (20,'Testing','NJ');
insert into dept5 values (30,'QMS','NP');
insert into dept5 values (40,'Accounts','ND');
insert into dept5 values (50,'Sales','NM');

