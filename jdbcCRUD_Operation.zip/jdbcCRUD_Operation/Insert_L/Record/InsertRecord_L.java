package jdbcCRUD_Operation.Insert_L.Record;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertRecord_L {
	public static void main(String[] args) {

		System.out.println("Program Started");
		Statement stmt=null;
		PreparedStatement pstmt=null;
		
	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306?collegedbms ",user="root"& password="root");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/collegedbms?", "root", "root");
			System.out.println("Connection SuccessFll");
			
			Scanner scan1 = new Scanner(System.in);
			Scanner scan2 = new Scanner(System.in);
			Scanner scan3 = new Scanner(System.in);
			
			System.out.println("Enter dept number : ");
			int dept_no = scan1.nextInt();
			

			System.out.println("Enter dept name : ");
			String dept_name= scan2.nextLine();

			System.out.println("Enter dept location  : ");
			String dept_loc = scan3.nextLine();
			
			pstmt=con.prepareStatement("insert into dept values (?,?,?)");
			
			pstmt.setInt(1, dept_no);
			pstmt.setString(2, dept_name);
			pstmt.setString(3, dept_loc);
			int rows = pstmt.executeUpdate();
			System.out.println("Row created : "+rows);
			
			
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			if(pstmt!=null)
			{
				try {
					pstmt.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		System.out.println("Program Ended");
	}

}
