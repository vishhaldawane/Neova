package jdbcCRUD_Operation.SelectRecord_L;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import jdbcCRUD_Operation.SelectRecord_L.DepartmentNotFoundException;
public class Select_Single_query_L {
	public static void main(String[] args) {

		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("DRIVER REGISTERED SUCCESSFULLY");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/collegedbms?", "root", "root");
			System.out.println("Connection SuccessFll");
			
			Statement stmt = con.createStatement();
			System.out.println("WHICH DEPT U WANT TO SEARCH ??? ");
			Scanner sc = new Scanner(System.in);
			int deptNumber = sc.nextInt();
			
			ResultSet rs= stmt.executeQuery("select * from dept where dept_no="+deptNumber);
			if( rs.next() ) {
				int dept_no = rs.getInt(1);
				String dept_name= rs.getString(2);
				String dept_loc= rs.getString(3);
				System.out.println("NUMBER    : "+dept_no);
				System.out.println("STRING1   : "+dept_name);
				System.out.println("STRING2   : "+dept_loc);
				System.out.println("--------------------");
			} else {
			
				throw new DepartmentNotFoundException("Department Does not exists!!!"+deptNumber);
				
			}
			
			rs.close();
			stmt.close();
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
	}


