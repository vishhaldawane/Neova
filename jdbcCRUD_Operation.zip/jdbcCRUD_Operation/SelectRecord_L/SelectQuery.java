package jdbcCRUD_Operation.SelectRecord_L;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectQuery {
	public static void main(String[] args) {
		System.out.println("Program Started");
			
		try {
			Class.forName("com.mysql.jdbc.Driver");
			//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306?collegedbms ",user="root"& password="root");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/collegedbms?", "root", "root");
			System.out.println("Connection SuccessFll");
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from dept");
			while( rs.next() ) {
				int dept_no = rs.getInt(1);
				String dept_name = rs.getString(2);
				String dept_loc = rs.getString(3);
				System.out.println("NUMBER    : "+dept_no);
				System.out.println("STRING1   : "+dept_name);
				System.out.println("STRING2   : "+dept_loc);
				System.out.println("--------------------");
			}	
			rs.close();
			stmt.close();
			con.close();
	} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Program Ended");
	}
}
