package jdbcCRUD_Operation.SelectRecord_L;

public class DepartmentNotFoundException extends Exception {
	 public DepartmentNotFoundException(String str) {
		 super(str);
	 }

}
