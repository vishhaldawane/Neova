package jdbcCRUD_Operation.UpdateRecord_L;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateQuery_L {
	public static void main(String[] args) {
		
	
	try {
		//1 - registration of Driver
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver Added Successfully...");
		//Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306?collegedbms ",user="root"& password="root");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/collegedbms?", "root", "root");
		System.out.println("Connection SuccessFll");
		
		
		
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		Scanner sc2 = new Scanner(System.in);
		System.out.println("In which dept number : ");
		int dept_no = sc.nextInt();
		

		System.out.println("ENTER THE NEW DEPT NAME : ");
		String dept_name = sc1.nextLine();

		System.out.println("ENTER THE NEW DEPT LOCATION: ");
		String dept_loc = sc2.nextLine();
		
		
		
		//3. - decide your statement   DQL / DML / PLSQL
		PreparedStatement pstmt = con.prepareStatement("update dept set dept_name=?, dept_loc=? where dept_no=?");;
		
		pstmt.setInt(3, dept_no);
		
		pstmt.setString(1, dept_name);
		pstmt.setString(2, dept_loc);
		
		int rows = pstmt.executeUpdate();
		System.out.println("NO OF ROW AFFECTED : "+rows);
		
		
		pstmt.close();
		con.close();
		
	} catch (SQLException | ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}
}

