package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.BankDetail;
import com.example.demo.layer2.Customer;
@Repository
public class CustomerRepositoryImpl extends BaseRepository implements CustomerRepository {

	
	@Transactional
	public void insertCustomer(Customer ref) {
		EntityManager entityManager = getEntityManager();
		entityManager.persist(ref); //based on PK
		System.out.println("Customer inserted..."+ref);

	}

	@Transactional
	public Customer selectCustomer(int customerNumber) {
		// TODO Auto-generated method stub
		return  getEntityManager().find(Customer.class, customerNumber);
	}

	@Transactional
	public List<Customer> selectAllCustomers() {
		// TODO Auto-generated method stub
		TypedQuery query = getEntityManager().createQuery("from Customer",Customer.class);
		return query.getResultList();
	}

	@Transactional
	public void updateCustomer(Customer cust) {
		// TODO Auto-generated method stub
		getEntityManager().merge(cust);
	}

	@Transactional
	public void deleteCustomer(int customerNumber) {
		// TODO Auto-generated method stub
	
	}

}
