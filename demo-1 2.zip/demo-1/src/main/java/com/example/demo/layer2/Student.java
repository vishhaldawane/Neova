package com.example.demo.layer2;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
/*
 * 
 * 		students
 * 		<----PK---->
 * 		STD	DIV	ROLL	NAME
 * 		X	A	1		LAKHAN
 * 		X	B	1		NIKITA
 * 		X	C	1		RISHI
 * 
 * 
 * 
 * 		student_marks							<--------PK------->
 * 		|										<---FK----->	
 * 	 	PHY	CHEM	MATHS	TOTAL	AVG	GRADE	STD	DIV	ROLL	SEM
 * 	 	90	88		99		 ...	..	..		X   A   1		1	
 * 	 	88	77		88		...		..	..		X	A	1		2
 * 	 	99	99		99		..		..	..		X	A	1		3
 * 		88	99		88		..		..	..		X	B	1		1
 */
@Entity
@Table(name="students")
public class Student {

	@EmbeddedId //composite primary key  [ std + div + rollno = StudentKey]
	StudentKey studKey; //composite primary is always referred by a composite foreign key

	String name;
	
	public Student(StudentKey studKey, String name) { // STD DIV ROLL NAME
		super();
		this.studKey = studKey;
		this.name = name;
	}




	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	//inner class
	@Embeddable
	public static class StudentKey implements Serializable
	{
		int std;
		String div;
		int rollno;
		
		
		public StudentKey() {
			super();
			// TODO Auto-generated constructor stub
		}
		public StudentKey(int std, String div, int rollno) {
			super();
			this.std = std;
			this.div = div;
			this.rollno = rollno;
		}
		
		
		//X  1  A  -- SequenceGenerator -- > R nd D
		//X  1  B
		//X  1  C
		//X  2  A
		//X  2  B
		//X  2  C
		//IX 1  A
		
		@Override
		public int hashCode() {
			return Objects.hash(div, rollno, std);
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StudentKey other = (StudentKey) obj;
			return Objects.equals(div, other.div) && rollno == other.rollno && std == other.std;
		}
		public int getStd() {
			return std;
		}
		public void setStd(int std) {
			this.std = std;
		}
		public String getDiv() {
			return div;
		}
		public void setDiv(String div) {
			this.div = div;
		}
		public int getRollno() {
			return rollno;
		}
		public void setRollno(int rollno) {
			this.rollno = rollno;
		}
		@Override
		public String toString() {
			return "StudentKey [std=" + std + ", div=" + div + ", rollno=" + rollno + "]";
		}
	
	}

	@Override
	public String toString() {
		return "Student [studKey=" + studKey + ", name=" + name + "]";
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	
	
	
}
