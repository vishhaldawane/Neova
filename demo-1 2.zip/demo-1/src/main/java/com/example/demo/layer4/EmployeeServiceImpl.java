package com.example.demo.layer4;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Employee;
import com.example.demo.layer2.EmployeeNotFoundException;
import com.example.demo.layer3.EmployeeRepositoryImpl;

@Service //@Component only
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepositoryImpl empRepo; //WOW, SPRING WUD INJECT THIS
	
	
	public void updateEmployeeService(Employee emp) {
		try {
			empRepo.updateEmployee(emp);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateEmployeeCustomerService(int empno, int custno)  //<-- values would come from Controller, <-- UI
	{
		//112
				try {
					Employee empObj = empRepo.selectEmployee(empno);
					
					Set<Customer> setOfCusts = empObj.getCustomers();
					
					for(Customer cust: setOfCusts) {
						if(cust.getCustomerId()==custno) {
							System.out.println("Customer id   : "+cust.getCustomerId());
							System.out.println("Customer name : "+cust.getCustomerName());
							System.out.println("Customer city : "+cust.getCity());
							System.out.println("-------------");
							cust.setCity(cust.getCity().toUpperCase());
							cust.setCustomerName(cust.getCustomerName().toUpperCase());
						}
					}
					empRepo.updateEmployee(empObj);
					
				} catch (EmployeeNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
	}
	
	public List<Employee> selectAllEmployeesService() { //SERIVCE 
		//business logic goes here if desired...
		System.out.println("EmployeeServiceImpl: Layer 4 ");
		//then talk to the kitchen code written below
		return empRepo.selectAllEmployees(); // IS CALLING REPO
	}

	@Override
	public Employee selectEmployeeService(int employeeNumber) throws EmployeeNotFoundException {
		// TODO Auto-generated method stub
		
		//LOGIC WILL COME HERE
		
		return empRepo.selectEmployee(employeeNumber);
	}

	@Override
	public void deleteEmployeeService(int empno)  {
		System.out.println("deleteEmployeeService()...method ");
		String message="Employee Not Found";
		
		boolean deleted=false;
		try {
			empRepo.deleteEmployee(empno);//invoke the repo
			deleted= true;
			message = "Employee Deleted";
			System.out.println("SErvice deleted :" );
		} catch (EmployeeNotFoundException e) {
			e.printStackTrace();
		//	message = e.getMessage();
			
		}
		
	}
	
//angular 6 dining--you (coding 5) ---> mother (service 4 ) ---->    maid (repo 3 )-->Bread 2 [ pojo ] Butter 2 -> market layer 1 
}
