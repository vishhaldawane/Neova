package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.BankDetail;
import com.example.demo.layer2.Customer;

@Repository
public class BankRepositoryImpl extends BaseRepository implements BankRepository {

	@Transactional
	public void insertBankDetail(BankDetail ref) {
		EntityManager entityManager = getEntityManager();
		entityManager.persist(ref); //based on PK
		System.out.println("BankDetail inserted..."+ref);

	}
	
	@Transactional
	public BankDetail selectBank(int accountNumber) {
		
		return getEntityManager().find(BankDetail.class, accountNumber);
	}

	@Transactional
	public void updateBank(BankDetail bd) {
		getEntityManager().merge(bd);

	}

	@Override
	public List<BankDetail> selectAllBanks() {
		
		TypedQuery query = getEntityManager().createQuery("from BankDetail",BankDetail.class);
		return query.getResultList();
	}

}
