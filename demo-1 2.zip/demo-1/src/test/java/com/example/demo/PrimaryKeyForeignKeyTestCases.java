package com.example.demo;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.BankDetail;
import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Department;
import com.example.demo.layer2.Employee;
import com.example.demo.layer2.Employee2;
import com.example.demo.layer2.EmployeeNotFoundException;
import com.example.demo.layer2.Student;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.BaseRepository;
import com.example.demo.layer3.CustomerRepository;
import com.example.demo.layer3.EmployeeRepository;
import com.example.demo.layer3.StudentRepoImpl;
import com.example.demo.layer4.StudentService;

@SpringBootTest
class PrimaryKeyForeignKeyTestCases { // <-- UPLOADED ON GITHUB AS demo-1.tar

	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	CustomerRepository custRepo;
	
	@Autowired
	BankRepository bankRepo;
	
	@Autowired
	BaseRepositoryImpl base;
	
	
	@Test
	void addNewEmployeeAlongWithNewBankDetails() {
		
		Employee emp = new Employee(106,"Vaishnavi",9000); //ur userdetails obj here
		
		//BankDetail thebank = new BankDetail(); //if sinlge bank for on emp
		//thebank.setName, setNumber, setBalance, setEmp(emp);
		
		Set<BankDetail> banks = new HashSet<BankDetail>(); //many banks for one emp
		
		banks.add(new BankDetail(1056,1,"AB1",3300,emp)); //<---watch emp is set here as FK
		banks.add(new BankDetail(1057,2,"AB2",4400,emp)); // emp as fk
		banks.add(new BankDetail(1058,3,"AB3",5500,emp)); //emp as fk
		
		emp.setBankDetails(banks); // all bank details are set to emp
		base.saveRecord(emp); //emp is saved... hence all the nested bank is also set in db

	}
	
	@Test
	void addNewEmployeeWithoutBankDetailAndCustomerChildren() {
		Employee newEmp = new Employee();
		newEmp.setEmployeeNumber(104);
		newEmp.setEmployeeName("JOY");
		newEmp.setEmployeeSalary(new Double(7000));
		try {
			empRepo.updateEmployee(newEmp);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Test
	void addNewCustomerWithoutParentEmployee() { //new customer added without its parent emp
		Customer newCust = new Customer(222,"LTI Sports","India");
		custRepo.updateCustomer(newCust); //for that call merge and not insert
		//the above line has created customer without parent emp's FK in it
		//DONT CALL PERSIST, RATHER CALL MERGE
	}
	
	@Test
	void addNewBankDetailWithoutParentEmployee() {
		BankDetail newBankDetail = new BankDetail(999,1,"ICICI Bank",85000);
		bankRepo.updateBank(newBankDetail);
		
	}
	
	@Test
	void assignExistingBankDetailToExistingEmployee() {
		
		try {
			Employee foundEmp = empRepo.selectEmployee(106);//YET doesnt have bank 
			BankDetail foundBankDetail = bankRepo.selectBank(1056); //yet doesnt have emp as fk
			//Set is captured for add(), since emp has One to Many bank details
			foundEmp.getBankDetails().add(foundBankDetail); 
			foundBankDetail.setEmployee(foundEmp); //<--SETTING empno->FK FOR BANK 
			bankRepo.updateBank(foundBankDetail);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	void assignExistingCustomerToExistingEmployee() {
		
		try {
			Employee foundEmp = empRepo.selectEmployee(102);//YET doesnt have customer
			Customer foundCustomer= custRepo.selectCustomer(222); //yet doesnt have emp as fk
			//Set is captured for add(), since emp has One to Many Customer details
			foundEmp.getCustomers().add(foundCustomer); 
			
			foundCustomer.setEmployee1(foundEmp); //<--SETTING empno->FK FOR BANK 
			
			custRepo.updateCustomer(foundCustomer);
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 
	 Airline
	 
	 FLIGHT SEARCH
	 flight reservation
	 SEAT SELECTION
	 ticket booking
	 ticket cancel
	 
	 
	 AGILE
	 
	 THALI
	 10 ITEMS
	 
	 1	1	1
	 4	3	3
	 
	 
	 REPO				Service				controller			UI
	 deptRepo			deptServive		deptController
	 	3					5
	 	(2)	--------------> (2)		--------->		------------->			
	 
	 empRepo			empService
	 	5					7
	 	(2)	---------------> (2)	
	 
	 
	 custRepo
	 	7
	 	(3)
	 	
	 	-----
	 	15 - 
	 	7 are working
	 	with junit
	 
	 */
	
	@Test
	public void showCustomersOfAnEmployee() {
		
		try {
			Employee emp = empRepo.selectEmployee(112);
			Set<Customer> setOfCusts = emp.getCustomers();
			
			for(Customer cust: setOfCusts) {
				System.out.println("Customer id   : "+cust.getCustomerId());
				System.out.println("Customer name : "+cust.getCustomerName());
				System.out.println("Customer city : "+cust.getCity());
				System.out.println("-------------");
				
			}
			
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	@Test
	public void updateCustomersOfAnEmployee() {
		
		try {
			Employee emp = empRepo.selectEmployee(112); //112's emp -> 102 customer
			Set<Customer> setOfCusts = emp.getCustomers();
			
			for(Customer cust: setOfCusts) {
				if(cust.getCustomerId()==102) {
					System.out.println("Customer id   : "+cust.getCustomerId());
					System.out.println("Customer name : "+cust.getCustomerName());
					System.out.println("Customer city : "+cust.getCity());
					System.out.println("-------------");
					cust.setCity(cust.getCity().toUpperCase());
					cust.setCustomerName(cust.getCustomerName().toUpperCase());
				}
			}
			
			empRepo.updateEmployee(emp);
			
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	//HOW TO DO THIS FROM POSTMAN TO SERVICE TO REPO??????
}


