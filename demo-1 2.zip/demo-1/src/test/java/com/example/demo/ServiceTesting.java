package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Customer;
import com.example.demo.layer2.Employee;
import com.example.demo.layer2.EmployeeNotFoundException;
import com.example.demo.layer4.EmployeeService;


@SpringBootTest
public class ServiceTesting {
	
	
	@Autowired
	EmployeeService empService;
	
	@Test
	public void updateCustomersOfAnEmployeeServiceTest()
	{
		
		//112
		try {
			Employee empObj = empService.selectEmployeeService(112);
			
			Set<Customer> setOfCusts = empObj.getCustomers();
			
			for(Customer cust: setOfCusts) {
				if(cust.getCustomerId()==101) {
					System.out.println("Customer id   : "+cust.getCustomerId());
					System.out.println("Customer name : "+cust.getCustomerName());
					System.out.println("Customer city : "+cust.getCity());
					System.out.println("-------------");
					cust.setCity(cust.getCity().toUpperCase());
					cust.setCustomerName(cust.getCustomerName().toUpperCase());
				}
			}
			empService.updateEmployeeService(empObj);
			
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
