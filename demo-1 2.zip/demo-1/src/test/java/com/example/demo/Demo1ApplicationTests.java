package com.example.demo;


import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.BankDetail;
import com.example.demo.layer2.Employee;
import com.example.demo.layer2.EmployeeNotFoundException;
import com.example.demo.layer2.Student;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.EmployeeRepository;
import com.example.demo.layer3.StudentRepoImpl;
import com.example.demo.layer4.StudentService;

@SpringBootTest
class Demo1ApplicationTests {

	@Autowired
	StudentRepoImpl stuRepo;
	
	@Autowired
	StudentService stuServ;
	
	@Autowired
	EmployeeRepository empRepo;
	
	@Autowired
	BankRepository bankRepo;
	
	@Test
	void assignExistingBankToExistingEmployee() {
		try {
			Employee emp = empRepo.selectEmployee(104);
			System.out.println("emp name : "+emp.getEmployeeName());
			System.out.println("emp's bank : "+emp.getBankDetails());
			Set<BankDetail> bankDetailsSet = emp.getBankDetails();
			
			BankDetail singleBankDetail = bankRepo.selectBank(114);
	/*1*/	System.out.println("Bank Acno : "+singleBankDetail.getBankAccountNumber());
	/*2*/	System.out.println("Bank NAME : "+singleBankDetail.getBankName());
	/*3*/	System.out.println("Bank BAL  : "+singleBankDetail.getBalance());
	/*4*/	singleBankDetail.setEmployee(emp);//important line - setting the fk 
			bankDetailsSet.add(singleBankDetail); //fill this bankdetail for the Set
			
			bankRepo.updateBank(singleBankDetail);
			
			//in your case
			// farmerpersonaldetail.setBankDetail(singleBankDetail); // for onetoone mapping 
			/*for(BankDetail singleBankDetail: bankDetailsSet) {
				System.out.println("Bank Acno : "+singleBankDetail.getBankAccountNumber());
				System.out.println("Bank NAME : "+singleBankDetail.getBankName());
				System.out.println("Bank BAL  : "+singleBankDetail.getBalance());
				
			}*/
			
		} catch (EmployeeNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
	@Test
	void createOneStudentTest() {
		System.out.println("Creating  a student...");
		Student.StudentKey skey = new Student.StudentKey(13,"C",33);
		Student s = new Student(skey,"JULIE");
		stuRepo.createStudent(s);	
	}
	
	@Test
	void updateOneStudentTest() {
		System.out.println("Loading a student...");
		Student.StudentKey skey = new Student.StudentKey(13,"C",33);
		Student s = stuRepo.getStudent(skey); //attached object with DB
		System.out.println("Current name is : "+s.getName());
		s.setName("JULIA"); //on attached object name is set | set method means update query
		stuRepo.updateStudent(s);	//update query fired,
	}
	
	@Test
	void loadOneStudentTest() {
		System.out.println("Loading a student...");
		Student s = stuRepo.getStudent(new Student.StudentKey(13,"C",33));
		System.out.println("s "+s);
	}
	
	
	@Test
	void loadAllStudentsTest() {
		System.out.println("Loading all the students...");
		List<Student> studentList = stuRepo.getAllStudents();
		System.out.println("studentList "+studentList.size());
		for (Student student : studentList) {
			System.out.println("Student : "+student);
		}
	}
	
	@Test
	void loadOneStudentServiceTest() {
		//stuServ.findStudentService();
	}
	
	@Test
	void updatedOneStudentServiceTest() {
		//stuServ.updateStudentService();
	}
}


