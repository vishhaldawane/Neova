
public class StringTest {
	public static void main(String[] args) {
		//string pool <-- shared data / resource
		
		String flower =new String("Rose");
		System.out.println("flower "+flower);
		System.out.println("flower at : "+flower.hashCode());
		
		flower = "Red Rose";
		
		System.out.println("flower "+flower);
		System.out.println("flower at : "+flower.hashCode());
		
		
		String flower2 = new String("Rose");
		System.out.println("flower2 "+flower2);
		System.out.println("flower2 at : "+flower2.hashCode());
		
		String flower3 = "Rose";
		System.out.println("flower3 "+flower3);
		System.out.println("flower3 at : "+flower3.hashCode());
		
		System.out.println("----------");
		
		StringBuffer name1 = new StringBuffer("Rajesh");
		System.out.println("name1 "+name1);
		System.out.println("name1 "+name1.hashCode());
		name1.append(" Sharma");
		System.out.println("name1 "+name1);
		System.out.println("name1 "+name1.hashCode());
		
		StringBuffer name2 = new StringBuffer("Rajesh");
		System.out.println("name2 "+name2);
		System.out.println("name2 "+name2.hashCode());
		
		
		StringBuilder  name3 = new StringBuilder();
		
		
		
	}
}
