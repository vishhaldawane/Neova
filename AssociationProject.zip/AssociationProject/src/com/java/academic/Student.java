package com.java.academic;

import com.java.personal.Person;

/*
public class Student extends Person { //isA

}*/
