package com.java.personal;

public class Story {
	
	private StringBuffer storyLines = new StringBuffer();

	public StringBuffer getStoryLines() {
		return storyLines;
	}

	public void setStoryLines(StringBuffer storyLines) {
		this.storyLines = storyLines;
	}
	
	
}
