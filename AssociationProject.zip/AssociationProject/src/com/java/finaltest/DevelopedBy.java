package com.java.finaltest;

public @interface DevelopedBy {

	String developer();

	double version();

}
