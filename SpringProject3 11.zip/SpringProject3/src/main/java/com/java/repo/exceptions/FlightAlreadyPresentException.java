package com.java.repo.exceptions;

public class FlightAlreadyPresentException extends Exception {

	public FlightAlreadyPresentException(String message) {
		super(message);
		
	}

	
}
