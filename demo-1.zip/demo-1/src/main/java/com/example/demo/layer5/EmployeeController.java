package com.example.demo.layer5;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Employee;


@Controller // it is a specialized version of @Component - marker to receive web request
@RequestMapping("/employees")
public class EmployeeController {
	
	@Autowired
	MailService mailService;
	
	List<Employee> empList = new ArrayList<Employee>();
	
	public EmployeeController() {
		
		empList.add(new Employee(101,"jack",5000));
		empList.add(new Employee(102,"jane",6000));
		empList.add(new Employee(103,"jill",7000));
		empList.add(new Employee(104,"joby",8000));
		empList.add(new Employee(105,"jim",9000));
		
	}
	
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/mailEmployee")
	String mailEmployee(@RequestBody Employee emp) {
		mailService.employeeRegistration(emp.getEmployeeName(),emp.getEmployeeEmail());
		return "Hello Employee, mail is sent"; //connect to the DB also via spring JPA
	}
	
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "/greet")
	String greetEmployee() {
		return "Hello Employee"; //connect to the DB also via spring JPA
	}
	
	@GetMapping
	@ResponseBody
	@RequestMapping(value="/getEmp/{eno}")
	public Employee getEmployee(@PathVariable int eno) {
		System.out.println("getEmployee()...method ");

		/*Employee emp = new Employee(); // spring JPA - get the data from DB
		emp.setEmployeeNumber(1010);
		emp.setEmployeeName("Jack");
		emp.setEmployeeSalary(5000);*/
		for (Employee employee : empList) {
			if(employee.getEmployeeNumber() == eno) {
				return employee;
			}
		}
		return null;
	}
	
	@GetMapping 
	@ResponseBody
	@RequestMapping(value = "/getAllEmps")
	public List<Employee> getEmployees() {
		System.out.println("getEmployees() ");
		return empList;
	}

	
	@PostMapping
	@ResponseBody
	@RequestMapping(value="/addEmp/{eno}/{enm}/{esal}")
	public String addEmployee(@PathVariable int eno, @PathVariable String enm,@PathVariable double esal) {
		System.out.println("addEmployee(eno,enm,esal)...method ");

		Employee emp = new Employee(); // spring JPA - get the data from DB
		emp.setEmployeeNumber(eno);
		emp.setEmployeeName(enm);
		emp.setEmployeeSalary(esal);
		empList.add(emp);
		return "Employee Added Successfulyy";
	}
	
	@PostMapping
	@ResponseBody
	@RequestMapping(value="/addEmp1")
	public String addEmployee1(@RequestBody Employee emp) {
		System.out.println("addEmployee1(@RequestBody emp)...method ");

		/*Employee emp = new Employee(); // spring JPA - get the data from DB
		emp.setEmployeeNumber(eno);
		emp.setEmployeeName(enm);
		emp.setEmployeeSalary(esal);*/
		empList.add(emp);
		return "Employee Added Successfulyy";
	}
	
	@PutMapping
	@ResponseBody
	@RequestMapping(value="/modifyEmp/{eno}/{enm}/{esal}")
	public String modifyEmployee(@PathVariable int eno, @PathVariable String enm,@PathVariable double esal) {
		System.out.println("modifyEmployee()...method ");
		String message="Employee Not Found";
		Employee newEmp= new Employee(eno,enm,esal);
		boolean modified=false;
		for (Employee employee : empList) {
			if(employee.getEmployeeNumber() == newEmp.getEmployeeNumber()) {
				int idx =empList.indexOf(employee);
				empList.set(idx, newEmp);
				modified=true;
				break;
			}
		}
		if(modified)
			message  = "Employee Modified Successfully"; 
		return message;
	}
	
	@DeleteMapping
	@ResponseBody
	@RequestMapping(value="/deleteEmp/{eno}")
	public String deleteEmployee(@PathVariable int eno) {
		System.out.println("deleteEmployee()...method ");
		String message="Employee Not Found";
		

		boolean deleted=false;
		for (Employee employee : empList) {
			if(employee.getEmployeeNumber() == eno) {
				int idx =empList.indexOf(employee);
				empList.remove(idx);
				deleted=true;
				break;
			}
		}
		if(deleted)
			message  = "Employee Deleted Successfully"; 
		return message;
	}
	
	 //   /greet for the web user
	//  greetEmployee() -> java developer
	
}
//http://localhost:8080/employees/greet

