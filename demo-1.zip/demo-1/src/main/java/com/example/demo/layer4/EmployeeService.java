package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Employee;
import com.example.demo.layer2.EmployeeNotFoundException;

@Service
public interface EmployeeService {

	Employee selectEmployeeService(int employeeNumber) throws EmployeeNotFoundException;
	List<Employee> selectAllEmployeesService() ;
	void deleteEmployeeService(int  empno) throws EmployeeNotFoundException;
}
