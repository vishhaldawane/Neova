package com.example.demo.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="bank")
public class BankDetail {

		@Id
		//@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name="bankid")
		int bankId;// bank_id // as  field in DB table
			
		@Column(name="bankaccountnumber")
		Integer bankAccountnumber;
		
		@Column(name="bankname")
		String bankname;
		
		@Column(name="balance")
		Integer balance;
		
		
		@ManyToOne
		@JoinColumn(name="eno")
		private Employee employee;


		
		
		
		public BankDetail() {
			super();
			// TODO Auto-generated constructor stub
		}


		public BankDetail(int bankId, Integer bankAccountnumber, String bankname, Integer balance,Employee employee) {
			super();
			this.bankId = bankId;
			this.bankAccountnumber = bankAccountnumber;
			this.bankname = bankname;
			this.balance = balance;
			this.employee=employee;
			
		}
		public BankDetail(int bankId, Integer bankAccountnumber, String bankname, Integer balance) {
			super();
			this.bankId = bankId;
			this.bankAccountnumber = bankAccountnumber;
			this.bankname = bankname;
			this.balance = balance;
			
			
		}

		public int getBankId() {
			return bankId;
		}


		public void setBankId(int bankId) {
			this.bankId = bankId;
		}


		public Integer getBankAccountNumber() {
			return bankAccountnumber;
		}


		public void setBankAccountNumber(Integer bankAccountNumber) {
			this.bankAccountnumber = bankAccountNumber;
		}


		public String getBankName() {
			return bankname;
		}


		public void setBankName(String bankName) {
			this.bankname = bankName;
		}


		public Integer getBalance() {
			return balance;
		}


		public void setBalance(Integer balance) {
			this.balance = balance;
		}


		@JsonIgnore
		public Employee getEmployee() {
			return employee;
		}


		public void setEmployee(Employee employee) {
			this.employee = employee;
		}
		
		
		
		
}
