package com.java.exceptions;

public class AccountNumberException extends Exception {
	
	//no data
	
	public AccountNumberException(String msg) {
		super(msg);
	}
	
	
	//no function
}
