package com.java.exceptions;

public class AccountHolderNameException extends Exception {

	public AccountHolderNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
		
}
