package com.java.finaltest;

public class Abc {

	public void fun(String string) {
		// TODO Auto-generated method stub
		
	}

}
